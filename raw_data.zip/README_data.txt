Raw per-run data used in the paper.
- results-java-websocket-* and results-commons-exec-*: second batch (workflow run #4, hard-kill timeouts). tests.csv = one row per test case per run; runs.csv = one row per started run (mvn_exit 124 = hung run killed by the 6-minute limit).
- run3-logback-nashorn: first batch (workflow run #3) for logback-core and delight-nashorn-sandbox. runs.csv there was rebuilt from tests.csv (seconds not available in this file; mean times come from the original run logs).
